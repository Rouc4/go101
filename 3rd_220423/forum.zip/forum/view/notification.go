package view

type NotificationPreview struct {
	ID        uint   `json:"id"`
	Type      string `json:"type"`
	PostID    uint   `json:"post_id"`
	BoardID   uint   `json:"board_id"`
	PostTitle string `json:"post_title"`
	Board     string `json:"board"`
	// Message string `json:"message"`
}

type NotificationCreate struct {
	PostID  uint
	BoardID uint
}

type NotificationMarkAsRead struct {
	NotificationID uint `json:"notification_id"`
}
