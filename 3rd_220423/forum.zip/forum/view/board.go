package view

type BoardPreview struct {
	ID   uint   `json:"id"`
	Name string `json:"name"`
}

type BoardView struct {
	ID                 uint   `json:"id"`
	Created            int64  `json:"created"`
	Name               string `json:"name"`
	Creator            string `json:"creator"`
	CreatorID          uint   `json:"creator_id"`
	IsSubscribed       bool   `json:"is_subscribed"`
	SubscriptionsCount int    `json:"subscriptions_count"`
}

type BoardCreate struct {
	Name       string `json:"name"`
	CreatorID  uint   `json:"creator_id"`
	CategoryID uint   `json:"category_id"`
}
