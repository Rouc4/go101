package view

type UserCreate struct {
	Username string `json:"username"`
	Avatar   string `json:"avatar_url"`
	Login    string `json:"login"`
	Email    string `json:"email"`
	ID       uint   `json:"id"`
}

type UserInfo struct {
	ID       uint   `json:"id"`
	Username string `json:"username"`
	Avatar   string `json:"avatar_url"`
	Login    string `json:"login"`
	Email    string `json:"email"`
	Role     string `json:"role"`
}

type UserProfile struct {
	ID       uint   `json:"id"`
	Username string `json:"username"`
	Avatar   string `json:"avatar_url"`
	Email    string `json:"email"`
	Karma    int    `json:"karma"`
}
