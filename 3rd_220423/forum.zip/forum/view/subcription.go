package view

type Subscription struct {
	BoardID uint `json:"board_id"`
}
