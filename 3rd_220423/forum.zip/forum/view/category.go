package view

type Category struct {
	ID     uint           `json:"id"`
	Name   string         `json:"name"`
	Boards []BoardPreview `json:"boards"`
}
