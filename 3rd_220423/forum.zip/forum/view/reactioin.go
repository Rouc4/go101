package view

type ReactionPost struct {
	PostID uint `json:"post_id"`
	Type   int  `json:"type"`
}

type ReactionComment struct {
	CommentID uint `json:"comment_id"`
	Type      int  `json:"type"`
}
