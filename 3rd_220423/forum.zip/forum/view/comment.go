package view

import "encoding/json"

type CommentPreview struct {
	ID       uint            `json:"id"`
	Content  json.RawMessage `json:"content"`
	Author   string          `json:"author"`
	Created  int64           `json:"created"`
	Likes    int             `json:"likes"`
	Dislikes int             `json:"dislikes"`
	ParentID uint            `json:"parent_id"`
	PostID   uint            `json:"post_id"`
	Reaction int             `json:"reaction"`
}

type CommentCreate struct {
	PostID   uint            `json:"post_id"`
	Content  json.RawMessage `json:"content"`
	AuthorID uint            `json:"author"`
	ParentID uint            `json:"parent_id"`
}

type CommentUpdate struct {
	ID      uint
	Content json.RawMessage `json:"content"`
}
