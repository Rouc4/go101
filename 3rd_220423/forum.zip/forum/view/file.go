package view

import uuid "github.com/satori/go.uuid"

type File struct {
	FileID   uuid.UUID
	Filename string
}
