package view

import "encoding/json"

type PostCreate struct {
	Title    string          `json:"title"`
	Content  json.RawMessage `json:"content"`
	AuthorID uint            `json:"author_id"`
	BoardID  uint            `json:"board_id"`
}

type PostPreview struct {
	ID       uint            `json:"id"`
	Title    string          `json:"title"`
	Content  json.RawMessage `json:"content"`
	Author   string          `json:"author"`
	Board    string          `json:"board"`
	Created  int64           `json:"created"`
	Likes    int             `json:"likes"`
	Dislikes int             `json:"dislikes"`
	Comments int             `json:"comments"`
	Reaction int             `json:"reaction"`
}

type PostView struct {
	ID       uint             `json:"id"`
	Title    string           `json:"title"`
	Content  json.RawMessage  `json:"content"`
	Author   string           `json:"author"`
	Board    string           `json:"board"`
	Created  int64            `json:"created"`
	Likes    int              `json:"likes"`
	Dislikes int              `json:"dislikes"`
	Reaction int              `json:"reaction"`
	Comments []CommentPreview `json:"comments"`
}

type PostUpdate struct {
	ID      uint
	Title   string          `json:"title"`
	Content json.RawMessage `json:"content"`
	// BoardID uint            `json:"board_id"`
}

type BoardPostsPreview struct {
	Board BoardView     `json:"board"`
	Posts []PostPreview `json:"posts"`
}
