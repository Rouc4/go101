package repository

import (
	"git.01.alem.school/PirozhokForAlem/forum/model"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/jinzhu/gorm"
)

type UserRepository struct {
	db *gorm.DB
}

func UserRepositoryInit(db *gorm.DB) *UserRepository {
	return &UserRepository{db: db}
}

func (r *UserRepository) RegisterUser(user view.UserCreate) error {

	model := model.User{
		Username: user.Username,
		Avatar:   user.Avatar,
		Login:    user.Login,
		Email:    user.Email,
		Model:    gorm.Model{ID: user.ID},
		RoleID:   1, // TODO select from db
	}

	return r.db.Save(&model).Error
}

func (r *UserRepository) GetUser(id uint) (view.UserInfo, error) {
	var model model.User
	err := r.db.Preload("Role").First(&model, id).Error
	return view.UserInfo{
		ID:       model.ID,
		Avatar:   model.Avatar,
		Email:    model.Email,
		Login:    model.Login,
		Role:     model.Role.Name,
		Username: model.Username,
	}, err
}

func (r *UserRepository) GetUserProfile(id uint) (view.UserProfile, error) {
	var user model.User
	err := r.db.Preload("Role").First(&user, id).Error
	if err != nil {
		return view.UserProfile{}, err
	}
	var likes, dislikes int
	err = r.db.Model(&model.Reaction{}).Where("author_id = ? and type = ?", id, model.Like).Count(&likes).Error
	if err != nil {
		return view.UserProfile{}, err
	}
	err = r.db.Model(&model.Reaction{}).Where("author_id = ? and type = ?", id, model.Dislike).Count(&dislikes).Error
	if err != nil {
		return view.UserProfile{}, err
	}
	return view.UserProfile{
		ID:       user.ID,
		Avatar:   user.Avatar,
		Email:    user.Email,
		Username: user.Username,
		Karma:    likes - dislikes,
	}, nil
}
