package repository

import (
	"git.01.alem.school/PirozhokForAlem/forum/model"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/jinzhu/gorm"
)

type ReactionRepository struct {
	db *gorm.DB
}

func ReactionRepositoryInit(db *gorm.DB) *ReactionRepository {
	return &ReactionRepository{db: db}
}

func (r *ReactionRepository) ReactionPost(reaction view.ReactionPost, authorID uint) error {
	var exist model.Reaction

	modelReaction := model.Reaction{
		PostID:   &reaction.PostID,
		AuthorID: authorID,
	}

	r.db.First(&exist, modelReaction)
	if exist.ID != 0 {
		r.db.Delete(&exist)
		if exist.Type == model.ReactionType(reaction.Type) {
			return nil
		}
	}

	modelReaction.Type = model.ReactionType(reaction.Type)

	return r.db.Save(&modelReaction).Error
}

func (r *ReactionRepository) ReactionComment(reaction view.ReactionComment, authorID uint) error {
	var exist model.Reaction

	modelReaction := model.Reaction{
		CommentID: &reaction.CommentID,
		AuthorID:  authorID,
	}

	r.db.First(&exist, modelReaction)
	if exist.ID != 0 {
		r.db.Delete(&exist)
		if exist.Type == model.ReactionType(reaction.Type) {
			return nil
		}
	}

	modelReaction.Type = model.ReactionType(reaction.Type)

	return r.db.Save(&modelReaction).Error
}
