package repository

import (
	"git.01.alem.school/PirozhokForAlem/forum/model"
	"github.com/jinzhu/gorm"
)

type SubscriptionRepository struct {
	db *gorm.DB
}

func SubscriptionRepositoryInit(db *gorm.DB) *SubscriptionRepository {
	return &SubscriptionRepository{db: db}
}

func (r *SubscriptionRepository) Subscribe(boardID, currentUserID uint) error {
	model := model.Subscription{
		BoardID: boardID,
		UserID:  currentUserID,
	}
	return r.db.FirstOrCreate(&model, model).Error
}

func (r *SubscriptionRepository) Unsubscribe(boardID, currentUserID uint) error {
	model := model.Subscription{
		BoardID: boardID,
		UserID:  currentUserID,
	}
	return r.db.Where("board_id = ? and user_id = ?", model.BoardID, currentUserID).Delete(&model).Error
}
