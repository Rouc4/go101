package repository

import (
	"git.01.alem.school/PirozhokForAlem/forum/model"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/jinzhu/gorm"
)

type BoardRepository struct {
	db *gorm.DB
}

func BoardRepositoryInit(db *gorm.DB) *BoardRepository {
	return &BoardRepository{db: db}
}

func (r *BoardRepository) GetBoardsByCategoryID(categoryID, currentUserID uint) ([]view.BoardView, error) {
	var boards []view.BoardView
	rows, err := r.db.Raw(sqlSelectBoards+" and b.category_id = ?", currentUserID, categoryID).Rows()

	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var b view.BoardView
		var subscribed int
		err = rows.Scan(&b.ID, &b.Name, &b.Creator, &b.CreatorID, &b.SubscriptionsCount, &subscribed)
		if err != nil {
			return nil, err
		}
		if subscribed > 0 {
			b.IsSubscribed = true
		}

		boards = append(boards, b)
	}
	return boards, nil
}

func (r *BoardRepository) GetBoardsByUserID(userID uint) ([]view.BoardView, error) {
	var boards []view.BoardView
	rows, err := r.db.Raw(sqlSelectBoards+" and s2.count > 0", userID).Rows()

	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var b view.BoardView
		var subscribed int
		err = rows.Scan(&b.ID, &b.Name, &b.Creator, &b.CreatorID, &b.SubscriptionsCount, &subscribed)
		if err != nil {
			return nil, err
		}
		if subscribed > 0 {
			b.IsSubscribed = true
		}

		boards = append(boards, b)
	}
	return boards, nil
}

func (r *BoardRepository) GetBoardByID(boardID, currentUserID uint) (view.BoardView, error) {
	var board model.Board
	err := r.db.First(&board, boardID).Error
	if err != nil {
		return view.BoardView{}, err
	}
	var count int
	r.db.Where("board_id = ?", boardID).Find(&model.Subscription{}).Count(&count)
	var subscribedCount int
	r.db.Where("board_id = ? and user_id = ?", boardID, currentUserID).Find(&model.Subscription{}).Count(&subscribedCount)
	isSubscribed := false
	if subscribedCount > 0 {
		isSubscribed = true
	}
	res := view.BoardView{
		ID:                 board.ID,
		Created:            board.CreatedAt.Unix(),
		Name:               board.Name,
		SubscriptionsCount: count,
		IsSubscribed:       isSubscribed,
	}
	if board.CreatorID != nil {
		res.Creator = board.Creator.Username
		res.CreatorID = *board.CreatorID
	}
	return res, nil
}

func (r *BoardRepository) CreateBoard(board view.BoardCreate) error {
	boardModel := model.Board{
		Name:       board.Name,
		CategoryID: board.CategoryID,
		CreatorID:  &board.CreatorID,
	}

	return r.db.Save(&boardModel).Error
}

var (
	sqlSelectBoards = `
	select b.id, b.name, coalesce(u.username, '') as creator, coalesce(b.creator_id, 0) as creator_id, coalesce(s.count, 0) as subscriptions_count, coalesce(s2.count, 0) as subscribed from boards b
		left join users u on b.creator_id = u.id
		left join (select board_id, count(1) from subscriptions where deleted_at isnull group by board_id) s on s.board_id = b.id
		left join (select board_id, count(1) from subscriptions where user_id = ? and deleted_at isnull group by board_id) s2 on s2.board_id = b.id
		where b.deleted_at isnull `
)
