package repository

import (
	"git.01.alem.school/PirozhokForAlem/forum/model"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/jinzhu/gorm"
)

type CategoryRepository struct {
	db *gorm.DB
}

func CategoryRepositoryInit(db *gorm.DB) *CategoryRepository {
	return &CategoryRepository{db: db}
}

func (r *CategoryRepository) GetAllCategories() ([]view.Category, error) {
	var categories []model.Category
	if err := r.db.Preload("Boards").Find(&categories).Error; err != nil {
		return nil, err
	}

	var res []view.Category
	for _, c := range categories {
		var boards []view.BoardPreview
		for _, t := range c.Boards {
			boards = append(boards, view.BoardPreview{
				ID:   t.ID,
				Name: t.Name,
			})
		}
		res = append(res, view.Category{
			ID:     c.ID,
			Name:   c.Name,
			Boards: boards,
		})
	}
	return res, nil
}
