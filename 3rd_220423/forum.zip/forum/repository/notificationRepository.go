package repository

import (
	"git.01.alem.school/PirozhokForAlem/forum/model"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/jinzhu/gorm"
)

type NotificationRepository struct {
	db *gorm.DB
}

func NotificationRepositoryInit(db *gorm.DB) *NotificationRepository {
	return &NotificationRepository{db: db}
}

func (r *NotificationRepository) CreateNewPostNotifications(notification view.NotificationCreate, currentUserID uint) error {
	var subscriptions []model.Subscription
	r.db.Where("board_id = ?", notification.BoardID).Find(&subscriptions)

	for _, sub := range subscriptions {
		if sub.UserID != currentUserID {
			notification := model.Notification{
				UserID:  sub.UserID,
				BoardID: notification.BoardID,
				PostID:  notification.PostID,
				Type:    model.NewPost,
			}
			if err := r.db.Save(&notification).Error; err != nil {
				return err
			}
		}
	}

	return nil
}

func (r *NotificationRepository) GetNotificationByUser(userID uint) ([]view.NotificationPreview, error) {
	var models []model.Notification
	r.db.Where("user_id = ?", userID).Preload("Post").Preload("Board").Find(&models)

	var notifications []view.NotificationPreview
	for _, n := range models {
		notifications = append(notifications, view.NotificationPreview{
			ID:        n.ID,
			Type:      n.Type.String(),
			BoardID:   n.BoardID,
			PostID:    n.PostID,
			Board:     n.Board.Name,
			PostTitle: n.Post.Title,
		})
	}
	return notifications, nil
}

func (r *NotificationRepository) DeleteNotification(notificationID, currentUserID uint) error {
	return r.db.Where("id = ? and user_id = ?", notificationID, currentUserID).Delete(&model.Notification{}).Error
}

func (r *NotificationRepository) DeleteNotificationByPost(postID, currentUserID uint) error {
	return r.db.Where("post_id = ? and user_id = ?", postID, currentUserID).Delete(&model.Notification{}).Error
}
