package repository

import (
	"strconv"
	"time"

	"git.01.alem.school/PirozhokForAlem/forum/model"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/jinzhu/gorm"
)

type CommentRepository struct {
	db *gorm.DB
}

func CommentRepositoryInit(db *gorm.DB) *CommentRepository {
	return &CommentRepository{db: db}
}

func (r *CommentRepository) CreateComment(comment view.CommentCreate) (uint, error) {
	model := model.Comment{
		Content:  comment.Content,
		AuthorID: comment.AuthorID,
		ParentID: comment.ParentID,
		PostID:   comment.PostID,
	}

	if err := r.db.Save(&model).Error; err != nil {
		return 0, err
	}
	return model.ID, nil
}

func (r *CommentRepository) GetCommentsByPost(postID, currentUserID uint) ([]view.CommentPreview, error) {
	comments := []view.CommentPreview{}

	rows, err := r.db.Raw(`select c.id, c.content, c.created_at as created, u.username as author, coalesce(l.count, 0) as likes, coalesce(d.count, 0) as dislikes, coalesce(r.type, 0) as reaction from comments c
	left join (select comment_id, count(1) from reactions where type = `+strconv.Itoa(int(model.Like))+` and deleted_at isnull group by comment_id) l on l.comment_id = c.id
	left join (select comment_id, count(1) from reactions where type = `+strconv.Itoa(int(model.Dislike))+` and deleted_at isnull group by comment_id) d on d.comment_id = c.id
	left join (select "type", comment_id from reactions where author_id = ? and deleted_at isnull) r on r.comment_id = c.id
	left join users u on c.author_id = u.id where c.post_id = ? and c.deleted_at isnull`, currentUserID, postID).Rows()

	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var c view.CommentPreview
		var created time.Time
		err = rows.Scan(&c.ID, &c.Content, &created, &c.Author, &c.Likes, &c.Dislikes, &c.Reaction)
		if err != nil {
			return nil, err
		}
		c.Created = created.Unix()
		c.PostID = postID
		comments = append(comments, c)
	}
	return comments, nil
}

func (r *CommentRepository) GetCommentsByUser(currentUserID uint) ([]view.CommentPreview, error) {
	comments := []view.CommentPreview{}

	rows, err := r.db.Raw(`select c.id, c.content, c.created_at as created, u.username as author, coalesce(l.count, 0) as likes, coalesce(d.count, 0) as dislikes, coalesce(r.type, 0) as reaction, c.post_id from comments c
	left join (select comment_id, count(1) from reactions where type = `+strconv.Itoa(int(model.Like))+` and deleted_at isnull group by comment_id) l on l.comment_id = c.id
	left join (select comment_id, count(1) from reactions where type = `+strconv.Itoa(int(model.Dislike))+` and deleted_at isnull group by comment_id) d on d.comment_id = c.id
	left join (select "type", comment_id from reactions where author_id = ? and deleted_at isnull) r on r.comment_id = c.id
	left join users u on c.author_id = u.id 
	where c.author_id = ? and c.deleted_at isnull`, currentUserID, currentUserID).Rows()

	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var c view.CommentPreview
		var created time.Time
		err = rows.Scan(&c.ID, &c.Content, &created, &c.Author, &c.Likes, &c.Dislikes, &c.Reaction, &c.PostID)
		if err != nil {
			return nil, err
		}
		c.Created = created.Unix()
		comments = append(comments, c)
	}
	return comments, nil
}

func (r *CommentRepository) UpdateComment(comment view.CommentUpdate) error {
	modelComment := model.Comment{
		Content: comment.Content,
	}

	if err := r.db.Model(&model.Comment{Model: gorm.Model{ID: comment.ID}}).Update(modelComment).Error; err != nil {
		return err
	}
	return nil
}

func (r *CommentRepository) GetCommentAuthorID(commentID uint) (uint, error) {
	var comment model.Comment
	err := r.db.First(&comment, commentID).Error
	return comment.AuthorID, err
}

func (r *CommentRepository) DeleteComment(commentID uint) error {
	return r.db.Where("id = ?", commentID).Delete(&model.Comment{}).Error
}
