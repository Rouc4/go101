package repository

import (
	"strconv"
	"time"

	"git.01.alem.school/PirozhokForAlem/forum/model"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/jinzhu/gorm"
)

type PostRepository struct {
	db *gorm.DB
}

func PostRepositoryInit(db *gorm.DB) *PostRepository {
	return &PostRepository{db: db}
}

func (r *PostRepository) CreatePost(post view.PostCreate) (uint, error) {
	model := model.Post{
		Title:    post.Title,
		Content:  post.Content,
		AuthorID: post.AuthorID,
		BoardID:  post.BoardID,
	}

	if err := r.db.Save(&model).Error; err != nil {
		return 0, err
	}
	return model.ID, nil
}

func (r *PostRepository) GetAllPosts(currentUserID uint) ([]view.PostPreview, error) {
	posts := []view.PostPreview{}

	rows, err := r.db.Raw(sqlSelectPosts+"where p.deleted_at isnull", currentUserID).Rows()

	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var p view.PostPreview
		var created time.Time
		err = rows.Scan(&p.ID, &p.Title, &p.Content, &created, &p.Board, &p.Author, &p.Comments, &p.Likes, &p.Dislikes, &p.Reaction)
		if err != nil {
			return nil, err
		}
		p.Created = created.Unix()
		posts = append(posts, p)
	}
	return posts, nil
}

func (r *PostRepository) GetPostsByBoard(boardID uint, currentUserID uint) ([]view.PostPreview, error) {
	posts := []view.PostPreview{}

	rows, err := r.db.Raw(sqlSelectPosts+"where b.id = ? and p.deleted_at isnull", currentUserID, boardID).Rows()

	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var p view.PostPreview
		var created time.Time
		err = rows.Scan(&p.ID, &p.Title, &p.Content, &created, &p.Board, &p.Author, &p.Comments, &p.Likes, &p.Dislikes, &p.Reaction)
		if err != nil {
			return nil, err
		}
		p.Created = created.Unix()
		posts = append(posts, p)
	}
	return posts, nil
}

func (r *PostRepository) GetPostsBySusbcriptions(currentUserID uint) ([]view.PostPreview, error) {
	posts := []view.PostPreview{}

	rows, err := r.db.Raw(sqlSelectPosts+`left join subscriptions s on b.id = s.board_id and s.deleted_at isnull
		where s.user_id = ? and p.deleted_at isnull`, currentUserID, currentUserID).Rows()

	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var p view.PostPreview
		var created time.Time
		err = rows.Scan(&p.ID, &p.Title, &p.Content, &created, &p.Board, &p.Author, &p.Comments, &p.Likes, &p.Dislikes, &p.Reaction)
		if err != nil {
			return nil, err
		}
		p.Created = created.Unix()
		posts = append(posts, p)
	}
	return posts, nil
}

func (r *PostRepository) GetPostsByUser(userID uint) ([]view.PostPreview, error) {
	posts := []view.PostPreview{}

	rows, err := r.db.Raw(sqlSelectPosts+`where p.author_id = ? and p.deleted_at isnull`, userID, userID).Rows()

	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var p view.PostPreview
		var created time.Time
		err = rows.Scan(&p.ID, &p.Title, &p.Content, &created, &p.Board, &p.Author, &p.Comments, &p.Likes, &p.Dislikes, &p.Reaction)
		if err != nil {
			return nil, err
		}
		p.Created = created.Unix()
		posts = append(posts, p)
	}
	return posts, nil
}

func (r *PostRepository) GetPostByID(postID, currentUserID uint) (view.PostView, error) {
	var post model.Post
	err := r.db.Table("posts").Preload("Author").Preload("Board").First(&post, postID).Error
	if err != nil {
		return view.PostView{}, err
	}
	var likes, dislikes int
	r.db.Model(&model.Reaction{}).Where("post_id = ? and type = ?", postID, model.Like).Count(&likes)
	r.db.Model(&model.Reaction{}).Where("post_id = ? and type = ?", postID, model.Dislike).Count(&dislikes)
	var reaction model.Reaction
	r.db.Where("post_id = ? and author_id = ?", postID, currentUserID).First(&reaction)
	return view.PostView{
		ID:       post.ID,
		Author:   post.Author.Username,
		Content:  post.Content,
		Created:  post.CreatedAt.Unix(),
		Board:    post.Board.Name,
		Title:    post.Title,
		Likes:    likes,
		Dislikes: dislikes,
		Reaction: int(reaction.Type),
	}, nil
}

func (r *PostRepository) UpdatePost(post view.PostUpdate) error {
	modelPost := model.Post{
		Title:   post.Title,
		Content: post.Content,
		// BoardID: post.BoardID,
	}

	return r.db.Model(&model.Post{Model: gorm.Model{ID: post.ID}}).Update(modelPost).Error
}

func (r *PostRepository) GetPostAuthorID(postID uint) (uint, error) {
	var post model.Post
	err := r.db.First(&post, postID).Error
	return post.AuthorID, err
}

func (r *PostRepository) DeletePost(postID uint) error {
	return r.db.Where("id = ?", postID).Delete(&model.Post{}).Error
}

var (
	sqlSelectPosts = `select p.id, p.title, p.content, p.created_at as created, b.name as board, u.username as author, coalesce(c.count, 0) as comments, coalesce(l.count, 0) as likes, coalesce(d.count, 0) as dislikes, coalesce(r.type, 0) as reaction from posts p
		left join (select post_id, count(1) from comments where deleted_at isnull group by post_id) c on c.post_id = p.id
		left join (select post_id, count(1) from reactions where type = ` + strconv.Itoa(int(model.Like)) + ` and deleted_at isnull group by post_id) l on l.post_id = p.id
		left join (select post_id, count(1) from reactions where type = ` + strconv.Itoa(int(model.Dislike)) + ` and deleted_at isnull group by post_id) d on d.post_id = p.id
		left join (select "type", post_id from reactions where author_id = ? and deleted_at isnull) r on r.post_id = p.id
		left join users u on p.author_id = u.id and u.deleted_at isnull
		left join boards b on p.board_id = b.id and b.deleted_at isnull `
)
