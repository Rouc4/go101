package repository

import (
	"git.01.alem.school/PirozhokForAlem/forum/model"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/jinzhu/gorm"
)

type FileRepository struct {
	db *gorm.DB
}

func FileRepositoryInit(db *gorm.DB) *FileRepository {
	return &FileRepository{db: db}
}

func (r *FileRepository) CreateFile(file view.File) error {
	model := model.File{
		FileID:   file.FileID.String(),
		Filename: file.Filename,
	}

	return r.db.Save(&model).Error
}

func (r *FileRepository) GetFile(fileID string) (view.File, error) {
	var file view.File
	err := r.db.Where("file_id = ?", fileID).First(&file).Error
	return file, err
}
