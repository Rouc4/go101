package main

import (
	"log"

	"git.01.alem.school/PirozhokForAlem/forum/config"
	"git.01.alem.school/PirozhokForAlem/forum/handler"
	"github.com/joho/godotenv"
)

func init() {
	if err := godotenv.Load(); err != nil {
		log.Print("No .env file found")
	}
}

func main() {
	config := config.GetConfig()

	app := &handler.App{}
	app.Initialize(config)
	app.Run(":8080")
}
