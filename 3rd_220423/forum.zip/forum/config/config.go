package config

import (
	"os"
	"strconv"
)

type Config struct {
	DB    *DBConfig
	OAuth *OAuthConfig
	JWT   *JWTConfig
}

type OAuthConfig struct {
	ClientID     string
	ClientSecret string
	RedirecURI   string
	Host         string
}

type DBConfig struct {
	Dialect  string
	Host     string
	Port     int
	Username string
	Password string
	Name     string
	Charset  string
}

type JWTConfig struct {
	SecretKey []byte
}

func GetConfig() *Config {
	return &Config{
		DB: &DBConfig{
			Dialect:  getEnv("DB__DIALECT", "postgres"),
			Host:     getEnv("DB__HOST", "localhost"),
			Port:     getEnvAsInt("DB__PORT", 5432),
			Username: getEnv("DB__USERNAME", "postgres"),
			Password: getEnv("DB__PASSWORD", "postgres"),
			Name:     getEnv("DB__NAME", ""),
		},
		OAuth: &OAuthConfig{
			ClientID:     getEnv("OAUTH__CLIENTID", ""),
			ClientSecret: getEnv("OAUTH__CLIENTSECRET", ""),
			RedirecURI:   getEnv("OAUTH__REDIRECTURI", ""),
			Host:         getEnv("OAUTH__HOST", ""),
		},
		JWT: &JWTConfig{
			SecretKey: []byte(getEnv("JWT__SECRETKEY", "")),
		},
	}
}

func getEnv(key string, defaultVal string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}

	return defaultVal
}

// Simple helper function to read an environment variable into integer or return a default value
func getEnvAsInt(name string, defaultVal int) int {
	valueStr := getEnv(name, "")
	if value, err := strconv.Atoi(valueStr); err == nil {
		return value
	}

	return defaultVal
}
