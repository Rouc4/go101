package model

import (
	"github.com/jinzhu/gorm"
	_ "github.com/lib/pq"
)

type ReactionType uint

const (
	Like ReactionType = iota + 1
	Dislike
)

type NotificationType uint

const (
	NewPost = iota
	NewComment
	NewCommentReply
)

func (n NotificationType) String() string {
	return [...]string{"New post", "New comment", "Comment reply"}[n]
}

type Role struct {
	gorm.Model
	Name string `gorm:"unique;not null"`
}

type User struct {
	gorm.Model
	Username string `gorm:"unique;not null"`
	Avatar   string `gorm:"not null"`
	Login    string `gorm:"unique;not null"`
	Email    string `gorm:"unique;not null"`
	RoleID   uint
	Role     Role
}

type Category struct {
	gorm.Model
	Name   string `gorm:"unique;not null"`
	Boards []Board
}

type Board struct {
	gorm.Model
	Name       string `gorm:"unique;not null"`
	CategoryID uint   `gorm:"not null"`
	Category   Category
	CreatorID  *uint
	Creator    User
}

type Reaction struct {
	gorm.Model
	PostID    *uint
	CommentID *uint
	AuthorID  uint         `gorm:"not null"`
	Type      ReactionType `gorm:"not null"`
}

type Subscription struct {
	gorm.Model
	UserID  uint `gorm:"not null"`
	BoardID uint `gorm:"not null"`
}

type Notification struct {
	gorm.Model
	UserID  uint `gorm:"not null"`
	User    User
	PostID  uint
	Post    Post
	BoardID uint
	Board   Board
	Type    NotificationType `gorm:"not null"`
}

type File struct {
	gorm.Model
	FileID   string `gorm:"not null"`
	Filename string `gorm:"not null"`
}

type Post struct {
	gorm.Model
	Title    string `gorm:"not null"`
	Content  []byte `gorm:"not null"`
	AuthorID uint   `gorm:"not null"`
	Author   User
	BoardID  uint `gorm:"not null"`
	Board    Board
	Comments []Comment `gorm:"ForeignKey:PostID"`
}

type Comment struct {
	gorm.Model
	Content  []byte
	AuthorID uint
	Author   User
	ParentID uint
	PostID   uint
	Post     Post
}

// DBMigrate will create and migrate the boards, and then make the some relationships if necessary
func DBMigrate(db *gorm.DB) *gorm.DB {
	db.AutoMigrate(&Post{}, &Comment{}, &Notification{}, &Subscription{}, &Reaction{}, &Board{}, &Category{}, &User{}, &Role{}, &File{})
	db.Model(&Comment{}).AddForeignKey("post_id", "posts(id)", "RESTRICT", "RESTRICT")
	db.Model(&Comment{}).AddForeignKey("author_id", "users(id)", "RESTRICT", "RESTRICT")
	db.Model(&Reaction{}).AddForeignKey("post_id", "posts(id)", "RESTRICT", "RESTRICT")
	db.Model(&Reaction{}).AddForeignKey("comment_id", "comments(id)", "RESTRICT", "RESTRICT")
	db.Model(&Reaction{}).AddForeignKey("author_id", "users(id)", "RESTRICT", "RESTRICT")
	db.Model(&Post{}).AddForeignKey("board_id", "boards(id)", "RESTRICT", "RESTRICT")
	db.Model(&Post{}).AddForeignKey("author_id", "users(id)", "RESTRICT", "RESTRICT")
	db.Model(&Notification{}).AddForeignKey("user_id", "users(id)", "RESTRICT", "RESTRICT")
	db.Model(&Subscription{}).AddForeignKey("user_id", "users(id)", "RESTRICT", "RESTRICT")
	db.Model(&Subscription{}).AddForeignKey("board_id", "boards(id)", "RESTRICT", "RESTRICT")
	db.Model(&Board{}).AddForeignKey("category_id", "categories(id)", "RESTRICT", "RESTRICT")
	db.Model(&Board{}).AddForeignKey("creator_id", "users(id)", "RESTRICT", "RESTRICT")
	db.Model(&User{}).AddForeignKey("role_id", "roles(id)", "RESTRICT", "RESTRICT")
	db.Model(&Notification{}).AddForeignKey("post_id", "posts(id)", "RESTRICT", "RESTRICT")
	db.Model(&Notification{}).AddForeignKey("board_id", "boards(id)", "RESTRICT", "RESTRICT")
	// db.Model(&Notification{}).AddForeignKey("comment_id", "comments(id)", "RESTRICT", "RESTRICT")

	roleUser := Role{Name: "user"}
	db.Where(roleUser).Assign(roleUser).FirstOrCreate(&roleUser)

	categories := []Category{
		{Name: "web", Boards: []Board{{Name: "Fullstack"}, {Name: "Front-end"}, {Name: "Back-end"}, {Name: "Framework"}}},
		{Name: "apps", Boards: []Board{{Name: "Kotlin"}, {Name: "PWA"}}},
		{Name: "vr/ar", Boards: []Board{{Name: "Oculus Rift"}, {Name: "HTC Vive"}}},
		{Name: "video games", Boards: []Board{{Name: "Netcode"}, {Name: "Unity"}, {Name: "C#"}, {Name: "Game Engines"}}},
		{Name: "data viz", Boards: []Board{{Name: "GraphQL"}, {Name: "Graph"}, {Name: "Mapping"}}},
		{Name: "big data", Boards: []Board{{Name: "Data science"}, {Name: "Analytics"}}},
		{Name: "ai", Boards: []Board{{Name: "Machine / Deep"}, {Name: "learning"}, {Name: "Neural network"}, {Name: "Natural language"}}},
		{Name: "blockchain", Boards: []Board{{Name: "Cryptocurrency"}, {Name: "Mining"}, {Name: "Signature"}, {Name: "Smart contracts"}}},
		{Name: "iot", Boards: []Board{{Name: "Smart devices"}, {Name: "Raspberry Pi"}, {Name: "Arduino"}, {Name: "Makers"}}},
		{Name: "dev ops admin", Boards: []Board{{Name: "Server"}, {Name: "Infrastructure"}, {Name: "Database"}}},
		{Name: "cyber security", Boards: []Board{{Name: "Pentest"}, {Name: "Bug bounty"}, {Name: "Hacker"}, {Name: "Virus"}}},
		{Name: "kernel dev", Boards: []Board{{Name: "Linux / Unix"}, {Name: "Driver"}, {Name: "Embedded"}, {Name: "System"}}},
	}
	for _, category := range categories {
		db.FirstOrCreate(&category, Category{Name: category.Name})
	}

	return db
}