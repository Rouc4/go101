package model

import (
	"git.01.alem.school/PirozhokForAlem/forum/view"
)

type PostRepository interface {
	CreatePost(post view.PostCreate) (uint, error)
	GetAllPosts(currentUserID uint) ([]view.PostPreview, error)
	GetPostByID(postID, currentUserID uint) (view.PostView, error)
	GetPostsByBoard(boardID, currentUserID uint) ([]view.PostPreview, error)
	GetPostsBySusbcriptions(currentUserID uint) ([]view.PostPreview, error)
	GetPostsByUser(userID uint) ([]view.PostPreview, error)
	UpdatePost(post view.PostUpdate) error
	GetPostAuthorID(postID uint) (uint, error)
	DeletePost(postID uint) error
}

type UserRepository interface {
	RegisterUser(user view.UserCreate) error
	GetUser(id uint) (view.UserInfo, error)
	GetUserProfile(id uint) (view.UserProfile, error)
}

type CommentRepository interface {
	CreateComment(comment view.CommentCreate) (uint, error)
	GetCommentsByPost(commentID, currentUserID uint) ([]view.CommentPreview, error)
	UpdateComment(post view.CommentUpdate) error
	GetCommentAuthorID(postID uint) (uint, error)
	DeleteComment(commentID uint) error
	GetCommentsByUser(currentUserID uint) ([]view.CommentPreview, error)
}

type ReactionRepository interface {
	ReactionPost(reaction view.ReactionPost, authorID uint) error
	ReactionComment(reaction view.ReactionComment, authorID uint) error
}

type SubscriptionRepository interface {
	Subscribe(boardID, currentUserID uint) error
	Unsubscribe(boardID, currentUserID uint) error
}

type NotificationRepository interface {
	CreateNewPostNotifications(notificatioin view.NotificationCreate, currentUserID uint) error
	GetNotificationByUser(userID uint) ([]view.NotificationPreview, error)
	DeleteNotification(notificationID, currentUserID uint) error
	DeleteNotificationByPost(postID, currentUserID uint) error
}

type CategoryRepository interface {
	GetAllCategories() ([]view.Category, error)
}

type BoardRepository interface {
	GetBoardsByCategoryID(categoryID, currentUserID uint) ([]view.BoardView, error)
	GetBoardsByUserID(userID uint) ([]view.BoardView, error)
	GetBoardByID(boardID, currentUserID uint) (view.BoardView, error)
	CreateBoard(board view.BoardCreate) error
}

type FileRepository interface {
	CreateFile(file view.File) error
	GetFile(fileID string) (view.File, error)
}
