package handler

import (
	"encoding/json"
	"net/http"

	"git.01.alem.school/PirozhokForAlem/forum/handler/util"
	"git.01.alem.school/PirozhokForAlem/forum/view"
)

func (a *App) GetUsersNotifications(w http.ResponseWriter, r *http.Request) {
	userID, _ := util.GetUserIDFromContext(r.Context())

	notifications, err := a.notificationRepo.GetNotificationByUser(userID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, notifications)
}

func (a *App) MarkAsRead(w http.ResponseWriter, r *http.Request) {
	notification := view.NotificationMarkAsRead{}

	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&notification); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer r.Body.Close()

	userID, _ := util.GetUserIDFromContext(r.Context())

	if err := a.notificationRepo.DeleteNotification(notification.NotificationID, userID); err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, nil)
}
