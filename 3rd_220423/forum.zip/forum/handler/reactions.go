package handler

import (
	"encoding/json"
	"net/http"

	"git.01.alem.school/PirozhokForAlem/forum/handler/util"
	"git.01.alem.school/PirozhokForAlem/forum/view"
)

func (a *App) ReactionPost(w http.ResponseWriter, r *http.Request) {
	reaction := view.ReactionPost{}

	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&reaction); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer r.Body.Close()

	userID, _ := util.GetUserIDFromContext(r.Context())

	if err := a.reactionRepo.ReactionPost(reaction, userID); err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, nil)
}

func (a *App) ReactionComment(w http.ResponseWriter, r *http.Request) {
	reaction := view.ReactionComment{}

	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&reaction); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer r.Body.Close()

	userID, _ := util.GetUserIDFromContext(r.Context())

	if err := a.reactionRepo.ReactionComment(reaction, userID); err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, nil)
}
