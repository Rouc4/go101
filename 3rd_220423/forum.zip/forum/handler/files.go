package handler

import (
	"io"
	"net/http"
	"os"

	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/gorilla/mux"
	uuid "github.com/satori/go.uuid"
)

func (a *App) UploadFile(w http.ResponseWriter, r *http.Request) {
	r.ParseMultipartForm(32 << 20)
	file, handler, err := r.FormFile("file")
	if err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer file.Close()

	fileID := uuid.NewV4()
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	f, err := os.OpenFile("./static/files/"+fileID.String(), os.O_WRONLY|os.O_CREATE, 0666)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	defer f.Close()
	io.Copy(f, file)

	fileInfo := view.File{
		FileID:   fileID,
		Filename: handler.Filename,
	}
	err = a.fileRepo.CreateFile(fileInfo)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, fileID)
}

func (a *App) DownloadFile(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)

	fileID := vars["file_id"]

	fileInfo, err := a.fileRepo.GetFile(fileID)
	if err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}

	f, err := os.OpenFile("./static/files/"+fileInfo.FileID.String(), os.O_RDONLY, 0666)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	defer f.Close()
	w.Header().Set("Content-Disposition", "attachment; filename="+fileInfo.Filename)
	w.Header().Set("Content-Type", "application/octet-stream")

	io.Copy(w, f)
}
