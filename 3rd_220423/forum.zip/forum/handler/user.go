package handler

import (
	"net/http"

	"git.01.alem.school/PirozhokForAlem/forum/handler/util"
)

func (a *App) GetUserProfile(w http.ResponseWriter, r *http.Request) {
	userID, _ := util.GetUserIDFromContext(r.Context())
	profile, err := a.userRepo.GetUserProfile(userID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, profile)
}
