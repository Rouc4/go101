package util

import "context"

type contextKey int

func (c contextKey) String() string {
	return string(c)
}

const (
	userIDKey contextKey = iota
	roleKey
	usernameKey
)

func GetUserIDFromContext(ctx context.Context) (uint, bool) {
	userID, ok := ctx.Value(userIDKey).(uint)
	return userID, ok
}

func SetUserIDToContext(ctx context.Context, userID uint) context.Context {
	return context.WithValue(ctx, userIDKey, userID)
}

func GetRoleFromContext(ctx context.Context) (string, bool) {
	role, ok := ctx.Value(roleKey).(string)
	return role, ok
}

func SetRoleToContext(ctx context.Context, role string) context.Context {
	return context.WithValue(ctx, roleKey, role)
}

func GetUsernameFromContext(ctx context.Context) (string, bool) {
	username, ok := ctx.Value(usernameKey).(string)
	return username, ok
}

func SetUsernameToContext(ctx context.Context, username string) context.Context {
	return context.WithValue(ctx, usernameKey, username)
}
