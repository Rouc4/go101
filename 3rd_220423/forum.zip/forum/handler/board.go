package handler

import (
	"encoding/json"
	"net/http"
	"strconv"

	"git.01.alem.school/PirozhokForAlem/forum/handler/util"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/gorilla/mux"
)

func (a *App) GetBoards(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)

	categoryID := vars["category_id"]

	id, err := strconv.Atoi(categoryID)
	if err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	currentUserID, _ := util.GetUserIDFromContext(r.Context())

	boards, err := a.boardRepo.GetBoardsByCategoryID(uint(id), currentUserID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, boards)
}

func (a *App) GetUsersBoards(w http.ResponseWriter, r *http.Request) {
	userID, _ := util.GetUserIDFromContext(r.Context())
	boards, err := a.boardRepo.GetBoardsByUserID(uint(userID))
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, boards)
}

func (a *App) CreateBoard(w http.ResponseWriter, r *http.Request) {
	board := view.BoardCreate{}

	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&board); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer r.Body.Close()

	board.CreatorID, _ = util.GetUserIDFromContext(r.Context())

	if err := a.boardRepo.CreateBoard(board); err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, board)
}
