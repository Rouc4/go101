package handler

import (
	"encoding/json"
	"net/http"

	"git.01.alem.school/PirozhokForAlem/forum/handler/util"
	"git.01.alem.school/PirozhokForAlem/forum/view"
)

func (a *App) Subscribe(w http.ResponseWriter, r *http.Request) {
	subscription := view.Subscription{}

	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&subscription); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer r.Body.Close()

	userID, _ := util.GetUserIDFromContext(r.Context())

	if err := a.subscriptionRepo.Subscribe(subscription.BoardID, userID); err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, nil)
}

func (a *App) Unsubscribe(w http.ResponseWriter, r *http.Request) {
	subscription := view.Subscription{}

	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&subscription); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer r.Body.Close()

	userID, _ := util.GetUserIDFromContext(r.Context())

	if err := a.subscriptionRepo.Unsubscribe(subscription.BoardID, userID); err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, nil)
}
