package handler

import (
	"encoding/json"
	"net/http"
	"strconv"
	"time"

	"git.01.alem.school/PirozhokForAlem/forum/handler/util"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/gorilla/mux"
)

func (a *App) CreateComment(w http.ResponseWriter, r *http.Request) {
	comment := view.CommentCreate{}

	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&comment); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer r.Body.Close()

	comment.AuthorID, _ = util.GetUserIDFromContext(r.Context())

	commentID, err := a.commentRepo.CreateComment(comment)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}

	username, _ := util.GetUsernameFromContext(r.Context())
	respondJSON(w, http.StatusCreated, view.CommentPreview{
		ID:       commentID,
		Content:  comment.Content,
		Created:  time.Now().Unix(),
		Author:   username,
		ParentID: comment.ParentID,
		PostID:   comment.PostID,
	})
}

func (a *App) UpdateComment(w http.ResponseWriter, r *http.Request) {
	comment := view.CommentUpdate{}

	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&comment); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer r.Body.Close()

	vars := mux.Vars(r)
	commentID := vars["comment_id"]
	id, err := strconv.Atoi(commentID)
	if err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	comment.ID = uint(id)

	currentUserID, _ := util.GetUserIDFromContext(r.Context())
	authorID, err := a.commentRepo.GetCommentAuthorID(comment.ID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	if currentUserID != authorID {
		respondError(w, http.StatusForbidden, "Not allowed")
		return
	}

	if err := a.commentRepo.UpdateComment(comment); err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}

	respondJSON(w, http.StatusCreated, comment)
}

func (a *App) DeleteComment(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	commentID := vars["comment_id"]
	id, err := strconv.Atoi(commentID)
	if err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}

	currentUserID, _ := util.GetUserIDFromContext(r.Context())
	authorID, err := a.commentRepo.GetCommentAuthorID(uint(id))
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	if currentUserID != authorID {
		respondError(w, http.StatusForbidden, "Not allowed")
		return
	}

	if err := a.commentRepo.DeleteComment(uint(id)); err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}

	respondJSON(w, http.StatusOK, nil)
}

func (a *App) GetCommentsByUser(w http.ResponseWriter, r *http.Request) {
	currentUserID, _ := util.GetUserIDFromContext(r.Context())

	comments, err := a.commentRepo.GetCommentsByUser(currentUserID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, comments)
}
