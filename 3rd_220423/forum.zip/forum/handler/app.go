package handler

import (
	"fmt"
	"log"
	"net/http"

	"git.01.alem.school/PirozhokForAlem/forum/config"
	"git.01.alem.school/PirozhokForAlem/forum/model"
	"git.01.alem.school/PirozhokForAlem/forum/repository"
	"github.com/gorilla/handlers"
	"github.com/gorilla/mux"
	"github.com/jinzhu/gorm"
)

// App has router and db instances
type App struct {
	Router *mux.Router
	config *config.Config

	postRepo         model.PostRepository
	userRepo         model.UserRepository
	commentRepo      model.CommentRepository
	reactionRepo     model.ReactionRepository
	categoryRepo     model.CategoryRepository
	boardRepo        model.BoardRepository
	subscriptionRepo model.SubscriptionRepository
	notificationRepo model.NotificationRepository
	fileRepo         model.FileRepository
}

// Initialize initializes the app with predefined configuration
func (a *App) Initialize(config *config.Config) {
	dbURI := fmt.Sprintf("port=%d host=%s user=%s password=%s dbname=%s sslmode=disable",
		config.DB.Port,
		config.DB.Host,
		config.DB.Username,
		config.DB.Password,
		config.DB.Name)
	a.config = config

	db, err := gorm.Open(config.DB.Dialect, dbURI)
	if err != nil {
		log.Fatal("Could not connect database", err)
	}

	db = model.DBMigrate(db)
	a.postRepo = repository.PostRepositoryInit(db)
	a.userRepo = repository.UserRepositoryInit(db)
	a.commentRepo = repository.CommentRepositoryInit(db)
	a.reactionRepo = repository.ReactionRepositoryInit(db)
	a.categoryRepo = repository.CategoryRepositoryInit(db)
	a.boardRepo = repository.BoardRepositoryInit(db)
	a.subscriptionRepo = repository.SubscriptionRepositoryInit(db)
	a.notificationRepo = repository.NotificationRepositoryInit(db)
	a.fileRepo = repository.FileRepositoryInit(db)

	router := mux.NewRouter()
	a.Router = router.PathPrefix("/api/v1/").Subrouter()
	a.setRouters()
}

// setRouters sets the all required routers
func (a *App) setRouters() {
	// Routing for handling the auth
	a.Get("/login", a.Login)
	a.Get("/oauth/redirect", a.Redirect)

	// Routing for handling the posts
	a.Get("/posts", a.AuthenticateMiddleware(a.GetAllPosts))
	a.Post("/posts", a.AuthenticateMiddleware(a.CreatePost))
	a.Get("/posts/board/{board_id}", a.AuthenticateMiddleware(a.GetPostsByBoard))
	a.Get("/posts/subscriptions", a.AuthenticateMiddleware(a.GetPostsBySubscriptions))
	a.Get("/posts/my", a.AuthenticateMiddleware(a.GetPostsByUser))
	a.Get("/posts/{post_id}", a.AuthenticateMiddleware(a.GetPost))
	a.Put("/posts/{post_id}", a.AuthenticateMiddleware(a.UpdatePost))
	a.Delete("/posts/{post_id}", a.AuthenticateMiddleware(a.DeletePost))

	// Routing for handling the comments
	a.Get("/comments/my", a.AuthenticateMiddleware(a.GetCommentsByUser))
	a.Put("/comments/{comment_id}", a.AuthenticateMiddleware(a.UpdateComment))
	a.Delete("/comments/{comment_id}", a.AuthenticateMiddleware(a.DeleteComment))
	a.Post("/comments", a.AuthenticateMiddleware(a.CreateComment))

	// Routing for handling the reactions
	a.Post("/reaction/post", a.AuthenticateMiddleware(a.ReactionPost))
	a.Post("/reaction/comment", a.AuthenticateMiddleware(a.ReactionComment))

	// Routing for handling the categories
	a.Get("/categories", a.AuthenticateMiddleware(a.GetAllCategories))

	// Routing for handling the boards
	a.Get("/boards/user", a.AuthenticateMiddleware(a.GetUsersBoards))
	a.Get("/boards/{category_id}", a.AuthenticateMiddleware(a.GetBoards))
	a.Post("/boards", a.AuthenticateMiddleware(a.CreateBoard))

	// Routing for handling the subscriptions
	a.Post("/subscribe", a.AuthenticateMiddleware(a.Subscribe))
	a.Post("/unsubscribe", a.AuthenticateMiddleware(a.Unsubscribe))

	// Routing for handling the notifications
	a.Get("/notifications", a.AuthenticateMiddleware(a.GetUsersNotifications))
	a.Post("/notifications", a.AuthenticateMiddleware(a.MarkAsRead))

	// Routing for handling the files
	a.Post("/upload", a.AuthenticateMiddleware(a.UploadFile))
	a.Get("/download/{file_id}", a.AuthenticateMiddleware(a.DownloadFile))

	// Routing for handling the profile
	a.Get("/profile", a.AuthenticateMiddleware(a.GetUserProfile))
}

// Get wraps the router for GET method
func (a *App) Get(path string, f func(w http.ResponseWriter, r *http.Request)) {
	a.Router.HandleFunc(path, f).Methods("GET")
}

// Post wraps the router for POST method
func (a *App) Post(path string, f func(w http.ResponseWriter, r *http.Request)) {
	a.Router.HandleFunc(path, f).Methods("POST")
}

// Put wraps the router for PUT method
func (a *App) Put(path string, f func(w http.ResponseWriter, r *http.Request)) {
	a.Router.HandleFunc(path, f).Methods("PUT")
}

// Delete wraps the router for DELETE method
func (a *App) Delete(path string, f func(w http.ResponseWriter, r *http.Request)) {
	a.Router.HandleFunc(path, f).Methods("DELETE")
}

// Run the app on it's router
func (a *App) Run(host string) {
	log.Println("Server started at", host)
	// TODO remove
	headersOk := handlers.AllowedHeaders([]string{"X-Requested-With"})
	originsOk := handlers.AllowedOrigins([]string{"*"})
	methodsOk := handlers.AllowedMethods([]string{"GET", "HEAD", "POST", "PUT", "OPTIONS", "DELETE"})

	log.Fatal(http.ListenAndServe(host, handlers.CORS(originsOk, headersOk, methodsOk)(a.Router)))
}
