package handler

import (
	"encoding/json"
	"net/http"
	"strconv"

	"git.01.alem.school/PirozhokForAlem/forum/handler/util"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/gorilla/mux"
)

func (a *App) GetAllPosts(w http.ResponseWriter, r *http.Request) {
	currentUserID, _ := util.GetUserIDFromContext(r.Context())
	posts, err := a.postRepo.GetAllPosts(currentUserID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, posts)
}

func (a *App) CreatePost(w http.ResponseWriter, r *http.Request) {
	post := view.PostCreate{}

	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&post); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer r.Body.Close()

	post.AuthorID, _ = util.GetUserIDFromContext(r.Context())
	postID, err := a.postRepo.CreatePost(post)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}

	notifi := view.NotificationCreate{
		BoardID: post.BoardID,
		PostID:  postID,
	}

	a.notificationRepo.CreateNewPostNotifications(notifi, post.AuthorID)

	respondJSON(w, http.StatusCreated, postID)
}

func (a *App) GetPost(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)

	postID := vars["post_id"]
	id, err := strconv.Atoi(postID)
	if err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	currentUserID, _ := util.GetUserIDFromContext(r.Context())
	post, err := a.postRepo.GetPostByID(uint(id), currentUserID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}

	a.notificationRepo.DeleteNotificationByPost(uint(id), currentUserID)

	post.Comments, _ = a.commentRepo.GetCommentsByPost(uint(id), currentUserID)
	respondJSON(w, http.StatusOK, post)
}

func (a *App) GetPostsByBoard(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)

	boardID := vars["board_id"]
	id, err := strconv.Atoi(boardID)
	if err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	currentUserID, _ := util.GetUserIDFromContext(r.Context())

	posts, err := a.postRepo.GetPostsByBoard(uint(id), currentUserID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	board, err := a.boardRepo.GetBoardByID(uint(id), currentUserID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, view.BoardPostsPreview{
		Board: board,
		Posts: posts,
	})
}

func (a *App) GetPostsByUser(w http.ResponseWriter, r *http.Request) {
	currentUserID, _ := util.GetUserIDFromContext(r.Context())

	posts, err := a.postRepo.GetPostsByUser(currentUserID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, posts)
}

func (a *App) GetPostsBySubscriptions(w http.ResponseWriter, r *http.Request) {
	currentUserID, _ := util.GetUserIDFromContext(r.Context())

	posts, err := a.postRepo.GetPostsBySusbcriptions(currentUserID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, posts)
}

func (a *App) UpdatePost(w http.ResponseWriter, r *http.Request) {
	post := view.PostUpdate{}

	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(&post); err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	defer r.Body.Close()

	vars := mux.Vars(r)
	postID := vars["post_id"]
	id, err := strconv.Atoi(postID)
	if err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}
	post.ID = uint(id)

	currentUserID, _ := util.GetUserIDFromContext(r.Context())
	authorID, err := a.postRepo.GetPostAuthorID(post.ID)
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	if currentUserID != authorID {
		respondError(w, http.StatusForbidden, "Not allowed")
		return
	}

	if err := a.postRepo.UpdatePost(post); err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}

	respondJSON(w, http.StatusOK, post)
}

func (a *App) DeletePost(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	postID := vars["post_id"]
	id, err := strconv.Atoi(postID)
	if err != nil {
		respondError(w, http.StatusBadRequest, err.Error())
		return
	}

	currentUserID, _ := util.GetUserIDFromContext(r.Context())
	authorID, err := a.postRepo.GetPostAuthorID(uint(id))
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	if currentUserID != authorID {
		respondError(w, http.StatusForbidden, "Not allowed")
		return
	}

	if err := a.postRepo.DeletePost(uint(id)); err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}

	respondJSON(w, http.StatusOK, nil)
}
