package handler

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"git.01.alem.school/PirozhokForAlem/forum/handler/util"
	"git.01.alem.school/PirozhokForAlem/forum/view"
	"github.com/dgrijalva/jwt-go"
)

func (a *App) Redirect(w http.ResponseWriter, r *http.Request) {
	err := r.ParseForm()
	if err != nil {
		fmt.Fprintf(os.Stdout, "could not parse query: %v", err)
		w.WriteHeader(http.StatusBadRequest)
	}
	code := r.FormValue("code")

	access, err := a.requestLogin(w, code)
	if err != nil {
		return
	}

	user, err := a.requestUser(w, access.AccessToken)
	if err != nil {
		return
	}

	err = a.userRepo.RegisterUser(*user)
	if err != nil {
		log.Println(err)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	userInfo, _ := a.userRepo.GetUser(user.ID)

	expirationTime := time.Now().Add(72 * time.Hour)
	claims := &Claims{
		UserID:   userInfo.ID,
		Role:     userInfo.Role,
		Username: userInfo.Username,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: expirationTime.Unix(),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString(a.config.JWT.SecretKey)
	if err != nil {
		log.Println(err)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	http.SetCookie(w, &http.Cookie{
		Name:    "token",
		Value:   tokenString,
		Expires: expirationTime,
		Path:    "/",
	})
	w.Header().Set("Location", "/")
	w.WriteHeader(http.StatusFound)
}

func (a *App) Login(w http.ResponseWriter, r *http.Request) {
	log.Println("login")
	location := fmt.Sprintf("%s/login/oauth/authorize?client_id=%s&redirect_uri=%s&response_type=code", a.config.OAuth.Host, a.config.OAuth.ClientID, a.config.OAuth.RedirecURI)

	w.Header().Set("Location", location)
	w.WriteHeader(http.StatusFound)
}

func (a *App) AuthenticateMiddleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		c, err := r.Cookie("token")
		if err != nil {
			if err == http.ErrNoCookie {
				w.WriteHeader(http.StatusUnauthorized)
				return
			}
			w.WriteHeader(http.StatusUnauthorized)
			return
		}

		tknStr := c.Value

		claims := &Claims{}
		tkn, err := jwt.ParseWithClaims(tknStr, claims, func(token *jwt.Token) (interface{}, error) {
			return a.config.JWT.SecretKey, nil
		})
		if err != nil {
			if err == jwt.ErrSignatureInvalid {
				w.WriteHeader(http.StatusUnauthorized)
				return
			}
			log.Println(err)
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		if !tkn.Valid {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}

		userID := claims.UserID
		ctx := util.SetUserIDToContext(r.Context(), uint(userID))
		ctx = util.SetRoleToContext(ctx, claims.Role)
		r = r.WithContext(ctx)
		log.Println(r.URL.Path)
		next.ServeHTTP(w, r)
	}
}

type RequestCode struct {
	ClientID     string `json:"client_id"`
	ClientSecret string `json:"client_secret"`
	Code         string `json:"code"`
	GrantType    string `json:"grant_type"`
	RedirectURI  string `json:"redirect_uri"`
}

type OAuthAccessResponse struct {
	AccessToken  string `json:"access_token"`
	TokenType    string `json:"token_type"`
	ExpiresIn    int    `json:"expires_in"`
	RefreshToken string `json:"refresh_token"`
}

type Claims struct {
	UserID   uint   `json:"user_id"`
	Username string `json:"username"`
	Role     string `json:"role"`
	jwt.StandardClaims
}

func (a *App) requestUser(w http.ResponseWriter, token string) (*view.UserCreate, error) {
	httpClient := http.Client{}
	getUserReq, err := http.NewRequest(http.MethodGet, a.config.OAuth.Host+"/api/v1/user", nil)
	if err != nil {
		fmt.Fprintf(os.Stdout, "could not create HTTP request: %v", err)
		w.WriteHeader(http.StatusBadRequest)
	}
	getUserReq.Header.Add("Authorization", "Bearer "+token)
	res, err := httpClient.Do(getUserReq)
	if err != nil {
		fmt.Fprintf(os.Stdout, "could not send HTTP request: %v", err)
		w.WriteHeader(http.StatusInternalServerError)
		return nil, err
	}
	defer res.Body.Close()
	resp, err := ioutil.ReadAll(res.Body)
	if err != nil {
		fmt.Fprintf(os.Stdout, "could not read JSON response: %v", err)
		w.WriteHeader(http.StatusBadRequest)
		return nil, err
	}
	log.Println(string(resp))
	var user view.UserCreate
	if err := json.Unmarshal(resp, &user); err != nil {
		fmt.Fprintf(os.Stdout, "could not parse JSON response: %v", err)
		w.WriteHeader(http.StatusBadRequest)
	}
	return &user, nil
}

func (a *App) requestLogin(w http.ResponseWriter, code string) (*OAuthAccessResponse, error) {
	reqData := RequestCode{
		ClientID:     a.config.OAuth.ClientID,
		ClientSecret: a.config.OAuth.ClientSecret,
		Code:         code,
		RedirectURI:  a.config.OAuth.RedirecURI,
		GrantType:    "authorization_code",
	}
	data, _ := json.Marshal(reqData)

	req, err := http.NewRequest(http.MethodPost, a.config.OAuth.Host+"/login/oauth/access_token", strings.NewReader(string(data)))
	if err != nil {
		fmt.Fprintf(os.Stdout, "could not create HTTP request: %v", err)
		w.WriteHeader(http.StatusBadRequest)
		return nil, err
	}

	req.Header.Set("accept", "application/json")
	req.Header.Set("content-type", "application/json")

	httpClient := http.Client{}
	res, err := httpClient.Do(req)
	if err != nil {
		fmt.Fprintf(os.Stdout, "could not send HTTP request: %v", err)
		w.WriteHeader(http.StatusInternalServerError)
		return nil, err
	}
	defer res.Body.Close()
	resp, _ := ioutil.ReadAll(res.Body)

	var access OAuthAccessResponse
	if err := json.Unmarshal(resp, &access); err != nil {
		fmt.Fprintf(os.Stdout, "could not parse JSON response: %v", err)
		w.WriteHeader(http.StatusBadRequest)
		return nil, err
	}
	return &access, nil
}
