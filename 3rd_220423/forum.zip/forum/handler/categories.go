package handler

import (
	"net/http"
)

func (a *App) GetAllCategories(w http.ResponseWriter, r *http.Request) {
	categories, err := a.categoryRepo.GetAllCategories()
	if err != nil {
		respondError(w, http.StatusInternalServerError, err.Error())
		return
	}
	respondJSON(w, http.StatusOK, categories)
}
